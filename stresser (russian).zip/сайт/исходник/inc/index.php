<?php
	header('Location: ../');
	exit;
?>