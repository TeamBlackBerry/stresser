<?php $page = "TOS";include 'header.php'; ?>

<main id="main-container" style="min-height: 404px;">
	<div class="content bg-gray-lighter">
		<div class="row items-push">
			<div class="col-sm-7">
				<h1 class="page-heading">TOS <small>Terms of Service</small></h1>
			</div>
			<div class="col-sm-5 text-right hidden-xs">
				<ol class="breadcrumb push-10-t">
					<li>Home</li><li><a class="link-effect" href="tos.php">TOS</a></li>
				</ol>
			</div>
		</div>
	</div>
	<div class="content content-boxed">
		<div class="block animated zoomInLeft">
			<div class="block-content block-content-full block-content-narrow">
				<h2 class="h6 font-w600 push-30-t push">				<p>1. When you access, login, relogin, register on Stresser you accept the TOS.</p>				<p>2. You aren't authorized to share your account or any information related to it. Account sharing is NOT ALLOWED! </p>				<p>3. You are **NOT** allowed to use our services for causing damage to internet connections/servers/websites... We provide legal Server Stress Testing services. Use the service only in your own server/network or only with authorization. This is your only warning, if you get caught your account will be banned. You will only be unbanned if you can prove that you either own the network or you are either authorized by the network administrator. Hitting any Gov site with Layer 7, Layer 4 or Layer 3 will be issued with a permanent ban without any refund.</p>				<p>4. When you make a payment on Stresser, you accept our TOS, chargebacks are strictly forbidden, As soon as you open a chargeback you will be banned! If you have any issue open a ticket!</p>				<p>5. All Stresser sales are final, no refunds will be issued.  </p>				<p>6. Spamming attacks or abusing the stop button is strictly forbidden and will result in a BAN. By using Stresser Stress Testing Tool you understand and agree that any damages caused related to the Stress Test launched is your own responsability.  </p>				<p>7. You must be respectful regarding the staff of Stresser. </p>				<p>8. If you get caught or admit breaking the TOS your account will be terminated. We reserve the right to modify the TOS at any time without notifying you.  </p>				<p>9. By using our legal Server Stress Testing service Stresser, you accept to be responsible for all consequences of your actions. </p>																</h6>
				
			</div>
		</div>
	</div>
</main>		
	
<?php include 'footer.php'; ?>