<?php

	$page = "Redeem Code";
	include 'header.php'; 

?>

<main id="main-container" style="min-height: 404px;"> 
	<div class="content bg-gray-lighter">
		<div class="row items-push">
			<div class="col-sm-8">
				<h1 class="page-heading"><?php echo $page; ?></h1>
			</div>
			<div class="col-sm-4 text-right hidden-xs">
				<ol class="breadcrumb push-10-t">
					<li>Home</li>
					<li><a class="link-effect" href="products.php"><?php echo $page; ?></a></li>
				</ol>
			</div>
		</div>
	</div>
	<div class="content content-narrow">
		<?php
		if(isset($notify)){
			echo '<div class="row col-md-12">' . $notify . "</div>";
		}
		?>
		<div class="row">  
		<div class="col-lg-12" id="div"></div>
		<div class="col-md-12">
			<div class="block">
				<div class="block-header bg-primary">
					<h3 class="block-title">Redeem Code <i style="display: none;" id="image" class="fa fa-cog fa-spin"></i></h3>
				</div>
				<div class="block-content">
					<form method="post" onsubmit="return false;">
						<div class="form-material floating">
							<input class="form-control" id="code" type="text">
							<label for="code">Enter the code here</label>
						</div>
						<div class="form-material floating">
							<button onclick="redeemCode()" class="btn btn-sm btn-primary btn-block">Redeem Code</button>
						</div>
					</form>
				</div>
			</div>
		</div>
      </div>
	</div>

</main>					
			<script>
			function redeemCode() {
				var code = $('#code').val();
				document.getElementById("image").style.display="inline"; 
				var xmlhttp;
				if (window.XMLHttpRequest) {
					xmlhttp=new XMLHttpRequest();
				}
				else {
					xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
				}
				xmlhttp.onreadystatechange=function() {
					if (xmlhttp.readyState==4 && xmlhttp.status==200) {
						document.getElementById("image").style.display="none";
						document.getElementById("div").innerHTML=xmlhttp.responseText;
						if (xmlhttp.responseText.search("SUCCESS") != -1) {
							inbox();
						}
					}
				}
				xmlhttp.open("GET","ajax/user/giftcodes/redeem.php?user=<?php echo $_SESSION['ID']; ?>" + "&code=" + code,true);
				xmlhttp.send();
			}
			</script>
      <!--/.row -->
<?php

	include 'footer.php';
	
?>