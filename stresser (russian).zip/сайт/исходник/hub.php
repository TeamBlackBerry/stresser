<?php
	$page = "Panel";
	include 'header.php';

	if (!($user->hasMembership($odb)) && $testboots == 0) {
		header('location: index.php');
		exit;
	}
?>
			<main id="main-container" style="min-height: 404px;">
                <div class="content bg-gray-lighter">
                    <div class="row items-push">
                        <div class="col-sm-7">
                            <h1 class="page-heading">Panel <small> Launch and manage attacks</small>
                            </h1>
                        </div>
                        <div class="col-sm-5 text-right hidden-xs">
                            <ol class="breadcrumb push-10-t">
                                <li>Home</li>
                                <li><a class="link-effect" href="hub.php">Panel</a></li>
                            </ol>
                        </div> 
                    </div>
                </div>
                <div class="content content-narrow">    
                    <div class="row">  
					<?php
					if (!($user -> isSupporter($odb))){
						if ($hub_status == 0) {			
							
							$hub_x = $hub_rtime + $hub_time;
					
							
							if($hub_x < time())
							{
								$SQLinsert = $odb -> prepare("UPDATE `settings` SET `hub_status` = '1', `hub_reason` = '', `hub_time` = '' WHERE 1");
								$SQLinsert -> execute(array());
								die('
								<div class="modal-dialog modal-dialog-popout">
							<div class="modal-content">
								<div class="block block-themed block-transparent remove-margin-b">
									<div class="block-header bg-primary-dark">
										<ul class="block-options">
											<li>
												<button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
											</li>
										</ul>
										<h3 class="block-title">xRage.xyz <i style="display: none;" id="manage2" class="fa fa-cog fa-spin"></i></h3>
									</div>
								<div class="block-content">
								<center>
								<h1>Hub is Enabled</h1>
								<h5>Refresh Page!</h5>
								</center>
								</div>
								</div>
							</div>
						</div>
								');
							} else {
								header('location: hub_.php');
								die();
							}
							}
					}
					?>
						<div class="col-lg-12" id="div"></div>
						<div class="col-lg-12">
							<?php
							if ($hub_status == 0) {
								echo '<div class="alert bg-success">
								<strong>SUCCESS:</strong> You are Admin, you can join!
							</div>';
							}
							?>
							<div class="alert bg-warning">
								<strong>READ:</strong> By clicking the Start button you agree to our <a href="tos.php">Terms of Service</a>
							</div>
						</div>
                        <div class="col-lg-4">                          
                            <div class="block block-themed">
                                <div class="block-header bg-primary">                                 
                                    <h3 class="block-title">
									<?php
									$user = $_SESSION['username'];
									$oneday = time() - 86400;
									$SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `user` LIKE :user AND `date` > :date");
									$SQL -> execute(array(":date" => $oneday, ':user' => $user));
									$todayattacks = $SQL->fetchColumn(0);
									?>
										Launch Attack
										<i style="display: none;" id="image" class="fa fa-cog fa-spin"></i>
									</h3>
                                </div>

                                <div class="block-content">
                                    <form class="form-horizontal push-10-t push-10" method="post" onsubmit="return false;">
                                        <div class="form-group">
                                            <div class="col-xs-6">
                                                <div class="form-material floating">
                                                    <input class="form-control" type="text" id="host" name="host">
                                                    <label for="host">Host</label>
                                                </div>
                                            </div>
                                            <div class="col-xs-6">
                                                <div class="form-material floating">
                                                    <input class="form-control" type="text" id="port" name="port">
                                                    <label for="port">Port</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-xs-12">
                                                <div class="form-material input-group floating">
                                                    <input class="form-control" type="text" id="time" name="time">
                                                    <label for="time">Time</label>
                                                    <span class="input-group-addon">seconds</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12">
												<div class="form-material floating open">
													<select class="form-control" id="method" name="method" size="1">
														<optgroup label=""></optgroup>
														<optgroup label="Layer4">
														<?php
														$SQLGetLogs = $odb->query("SELECT * FROM `methods` WHERE `type` = 'layer4' ORDER BY `id` ASC");
														while ($getInfo = $SQLGetLogs->fetch(PDO::FETCH_ASSOC)) {
															$name = $getInfo['name'];
															$fullname = $getInfo['fullname'];
															echo '<option value="' . htmlentities($name) . '">' . htmlentities($fullname) . '</option>';
														}
														?>
														</optgroup>
														<optgroup label="Layer7">
														<?php
															$SQLGetLogs = $odb->query("SELECT * FROM `methods` WHERE `type` = 'layer7' ORDER BY `id` ASC");
															while ($getInfo = $SQLGetLogs->fetch(PDO::FETCH_ASSOC)) {
																$name     = $getInfo['name'];
																$fullname = $getInfo['fullname'];
																echo '<option value="' . $name . '">' . $fullname . '</option>';
															}
														?>
														</optgroup>
													</select>
												</div>
                                            </div>
                                        </div>      
                                        <div class="form-group">
                                            <div class="col-xs-12 text-center">                                             
												<button class="btn btn-sm btn-success" onclick="start()" type="submit">
													<i class="fa fa-plus push-5-r"></i> Start
												</button>							
												<!-- <button data-toggle="modal" data-target="#servers" class="btn btn-sm btn-primary" type="submit">
													<i class="fa fa-download push-5-r"></i> Servers
												</button> !-->
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div> 
                        </div>
						<div class="col-lg-8">
                            <div class="block">
                                <div class="block-header bg-primary">
									<h3 class="block-title">
										Manage Attacks
										<i style="display: none;" id="manage" class="fa fa-cog fa-spin"></i>
									</h3>
								</div>
                                <div class="block-content">
									<div class="animated zoomIn" id="attacksdiv" style="display:inline-block;width:100%"></div>
                                </div>
                            </div>
                        </div>
                    </div>     
                </div>
            </main>
		<script>
		attacks();
		getip();
		getfae();
		getservers();
	
		function attacks() {
			document.getElementById("attacksdiv").style.display = "none";
			document.getElementById("manage").style.display = "inline"; 
			var xmlhttp;
			if (window.XMLHttpRequest) {
				xmlhttp = new XMLHttpRequest();
			}
			else {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
					document.getElementById("attacksdiv").innerHTML = xmlhttp.responseText;
					document.getElementById("manage").style.display = "none";
					document.getElementById("attacksdiv").style.display = "inline-block";
					document.getElementById("attacksdiv").style.width = "100%";
					eval(document.getElementById("ajax").innerHTML);
				}
			}
			xmlhttp.open("GET","ajax/user/attacks/attacks.php",true);
			xmlhttp.send();
		}
		
		function getservers() {
			var xmlhttp;
			if (window.XMLHttpRequest) {
				xmlhttp = new XMLHttpRequest();
			}
			else {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
					document.getElementById("serverss").innerHTML = xmlhttp.responseText;
					eval(document.getElementById("ajax").innerHTML);
				}
			}
			xmlhttp.open("GET","ajax/user/tools/servers.php",true);
			xmlhttp.send();
		}

		function start() {
			var host=$('#host').val();
			var port=$('#port').val();
			var time=$('#time').val();
			var method=$('#method').val();
			var vipmode=$('input:checkbox:checked').val();
			document.getElementById("image").style.display="inline"; 
			document.getElementById("div").style.display="none"; 
			var xmlhttp;
			if (window.XMLHttpRequest) {
				xmlhttp=new XMLHttpRequest();
			}
			else {
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function() {
				if (xmlhttp.readyState==4 && xmlhttp.status==200) {
					document.getElementById("div").innerHTML=xmlhttp.responseText;
					document.getElementById("div").style.display="inline";
					document.getElementById("image").style.display="none";
					if (xmlhttp.responseText.search("success") != -1) {
						attacks();
						window.setInterval(ping(host),10000);
					}
				}
			}
			xmlhttp.open("GET","ajax/user/attacks/hub.php?type=start" + "&host=" + host + "&port=" + port + "&time=" + time + "&method=" + method + "&vipmode=" + vipmode,true);
			xmlhttp.send();
		}

		function renew(id) {
			document.getElementById("manage").style.display="inline"; 
			document.getElementById("div").style.display="none"; 
			var xmlhttp;
			if (window.XMLHttpRequest) {
				xmlhttp=new XMLHttpRequest();
			}
			else {
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function() {
				if (xmlhttp.readyState==4 && xmlhttp.status==200) {
					document.getElementById("div").innerHTML=xmlhttp.responseText;
					document.getElementById("div").style.display="inline";
					document.getElementById("manage").style.display="none";
					if (xmlhttp.responseText.search("success") != -1) {
						attacks();
						window.setInterval(ping(host),10000);
					}
				}
			}
			xmlhttp.open("GET","ajax/user/attacks/hub.php?type=renew&id=" + id,true);
			xmlhttp.send();
		}

		function stop(id) {
			document.getElementById("manage").style.display="inline"; 
			document.getElementById("div").style.display="none"; 
			var xmlhttp;
			if (window.XMLHttpRequest) {
				xmlhttp=new XMLHttpRequest();
			}
			else {
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function() {
				if (xmlhttp.readyState==4 && xmlhttp.status==200) {
					document.getElementById("div").innerHTML=xmlhttp.responseText;
					document.getElementById("div").style.display="inline";
					document.getElementById("manage").style.display="none";
					if (xmlhttp.responseText.search("success") != -1) {
						attacks();
						window.setInterval(ping(host),10000);
					}
				}
			}
			xmlhttp.open("GET","ajax/user/attacks/hub.php?type=stop" + "&id=" + id,true);
			xmlhttp.send();
		}
		</script>
		<div class="modal" id="servers" tabindex="-1" role="dialog" aria-hidden="false" style="display: non;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="block block-themed block-transparent remove-margin-b">
                        <div class="block-header bg-primary-dark">
                            <ul class="block-options">
                                <li>
                                    <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                                </li>
                            </ul>
                            <h3 class="block-title">
								Servers
							</h3>
                        </div>
                        <div class="block-content">
                            <div class="block">
                                <div id="live_servers"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php

	include 'footer.php';

?>