<?php
	
	header('Location: home.php');
	exit;
	
?>